package com.example.divisasrecycler;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DivisaRVAdapter extends RecyclerView.Adapter<DivisaRVAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<DivisaModel> divisaModels;

    public DivisaRVAdapter(Context context, ArrayList<DivisaModel> divisaModels){
        this.context = context;
        this.divisaModels = divisaModels;
    }

    @NonNull
    @Override
    public DivisaRVAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.cv_row, parent,false);
        return new DivisaRVAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DivisaRVAdapter.MyViewHolder holder, int position) {
        DivisaModel currentDivisa = divisaModels.get(position);

        holder.tvSiglas.setText(currentDivisa.getSiglaDivisa());
        holder.tvNombre.setText(currentDivisa.getNombreDivisa());
        holder.tvValor.setText(currentDivisa.getValorDivisa());
        holder.ivImagenesDivisas.setImageDrawable(currentDivisa.getImagenDivisa());

        // Verifica si el elemento está seleccionado y actualiza el color de fondo
        int colorFondo = ContextCompat.getColor(context, R.color.grisazeo_feucho);
        if (currentDivisa.isSelected()) {
            holder.itemView.setBackgroundColor(colorFondo);
        } else {
            // Restaura el color de fondo predeterminado cuando no está seleccionado
            holder.itemView.setBackgroundColor(ContextCompat.getColor(context, android.R.color.transparent));
        }

        // Agrega el clic del elemento
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Deselecciona el elemento previamente seleccionado
                for (DivisaModel divisa : divisaModels) {
                    divisa.setSelected(false);
                }

                // Selecciona el nuevo elemento
                currentDivisa.setSelected(true);

                // Notifica al adaptador que los datos han cambiado para actualizar la interfaz de usuario
                notifyDataSetChanged();
                MainActivity.valorDivisaSeleccionada = Double.parseDouble(holder.tvValor.getText().toString());

            }
        });
    }

    @Override
    public int getItemCount() {
        return divisaModels.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvSiglas, tvNombre, tvValor;
        ImageView ivImagenesDivisas;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            this.tvSiglas = itemView.findViewById(R.id.tvSiglasDivisa);
            this.tvNombre = itemView.findViewById(R.id.tvNombreDivisas);
            this.tvValor = itemView.findViewById(R.id.tvValor);
            this.ivImagenesDivisas = itemView.findViewById(R.id.ivImagenesDivisas);
        }
    }
}

