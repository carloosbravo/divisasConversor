package com.example.divisasrecycler;

import android.graphics.drawable.Drawable;

public class DivisaModel {

    public String siglaDivisa;
    public String nombreDivisa;
    public String valorDivisa;
    private boolean isSelected;
    public Drawable imagenDivisa;

    public DivisaModel(String siglaDivisa, String nombreDivisa, String valorDivisa, Drawable imagenDivisa) {
        this.siglaDivisa = siglaDivisa;
        this.nombreDivisa = nombreDivisa;
        this.valorDivisa = valorDivisa;
        this.imagenDivisa = imagenDivisa;
        this.isSelected = false;
    }

    public String getSiglaDivisa() {
        return siglaDivisa;
    }

    public String getNombreDivisa() {
        return nombreDivisa;
    }

    public String getValorDivisa() {
        return valorDivisa;
    }

    public Drawable getImagenDivisa() {return imagenDivisa;}

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
