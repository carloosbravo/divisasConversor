package com.example.divisasrecycler;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<DivisaModel> divisaModels = new ArrayList<>();
    public static double valorDivisaSeleccionada;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.divisasRecyclerView);
        setdivisaModel();

        DivisaRVAdapter adapter = new DivisaRVAdapter(this,divisaModels);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Button btnConvertir = findViewById(R.id.btnConvertir);

        btnConvertir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText etCantidadIntroducida = findViewById(R.id.etIntroducirCantidad);
                TextView tvResultado = findViewById(R.id.tvResultado);
                Switch switchVIP = findViewById(R.id.switchVIP);

                try {
                    // Intenta convertir el valor introducido a double
                    double valorIntroducido = Double.parseDouble(etCantidadIntroducida.getText().toString());

                    // Resto del código
                    double resultado = valorDivisaSeleccionada * valorIntroducido;
                    double resultadoConIntereses = resultado - (valorDivisaSeleccionada * valorIntroducido * 0.02);

                    if (switchVIP.isChecked()) {
                        tvResultado.setText(String.valueOf(resultado));
                    } else {
                        tvResultado.setText(String.valueOf(resultadoConIntereses));
                    }

                } catch (NumberFormatException e) {
                    // Manejo de la excepción si el valor no es un número válido
                    Toast.makeText(MainActivity.this, "Por favor, introduce un valor válido", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void setdivisaModel() {
        String[] divisaSiglas = getResources().getStringArray(R.array.siglasDivisas);
        String[] divisasNombre = getResources().getStringArray(R.array.nombresDivisas);
        String[] divisasValor = getResources().getStringArray(R.array.valorDivisas);

        TypedArray typedArray = getResources().obtainTypedArray(R.array.imagenesDivisas);
        Drawable[] imagenesDivisas = new Drawable[typedArray.length()];

        for (int i = 0;i< typedArray.length();i++){
            int id = typedArray.getResourceId(i,0);
            if(id != 0){
                imagenesDivisas[i] = ContextCompat.getDrawable(this,id);
            }
        }
        typedArray.recycle();

        for(int i = 0;i<divisasNombre.length;i++){
            divisaModels.add(new DivisaModel(
                    divisaSiglas[i],
                    divisasNombre[i],
                    divisasValor[i],
                    imagenesDivisas[i]

            ));
        }

    }




}